#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// OLED Screen dimensions
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C // I2C Address for 0.96" OLED Display

// Create display object
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Pin Definitions
const int SENSOR_PIN = 34; // Pin 34 connected to Temperature Sensor / Slider
const int RELAY_PIN  = 4;  // Pin 4 connected to Relay Signal

// Temperature threshold in Celsius
const float TEMP_THRESHOLD = 45.0;

void setup() {
  Serial.begin(115200);

  // Configure Relay Pin
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW); // Keep power ON in normal state

  // Initialize I2C communication (SDA = Pin 21, SCL = Pin 22)
  Wire.begin(21, 22);

  // Start OLED display
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("OLED initialization failed!"));
    for(;;); // Stop execution if screen fails
  }

  // Welcome Screen
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(10, 20);
  display.println("EV BATTERY SYSTEM");
  display.setCursor(20, 40);
  display.println("INITIALIZING...");
  display.display();
  delay(2000);
}

void loop() {
  // 1. Read Raw ADC Value from Pin 34 (0 to 4095 on ESP32)
  int rawADC = analogRead(SENSOR_PIN);

  // 2. Convert ADC value to Voltage (3.3V reference)
  float voltage = rawADC * (3.3 / 4095.0);

  // 3. Convert Voltage to Temperature in Celsius (LM35 gives 10mV per °C)
  float tempC = voltage * 100.0;

  // Print value to Serial Monitor for debugging
  Serial.print("Current Temperature: ");
  Serial.print(tempC);
  Serial.println(" C");

  // 4. Update Screen & Check Safety Threshold
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("BMS MONITORING");
  display.println("---------------------");

  // Show live temperature reading
  display.setTextSize(2);
  display.setCursor(0, 20);
  display.print("TEMP: ");
  display.print(tempC, 1);
  display.print("C");

  display.setTextSize(1);
  display.setCursor(0, 50);

  if (tempC >= TEMP_THRESHOLD) {
    // DANGER STATE: Trip relay to cut off battery power
    digitalWrite(RELAY_PIN, HIGH); 
    
    display.println("STATUS: OVERHEAT!");
    display.setCursor(0, 58);
    display.println("RELAY: POWER CUT OFF");
  } else {
    // NORMAL STATE: Keep power flowing
    digitalWrite(RELAY_PIN, LOW); 
    
    display.println("STATUS: NORMAL");
    display.setCursor(0, 58);
    display.println("RELAY: POWER ACTIVE");
  }

  // Render to OLED screen
  display.display();

  // Wait 1 second before next temperature reading
  delay(1000);
}